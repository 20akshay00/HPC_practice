void boundarypsi(double *psi, int m, int n, int b, int h, int w);
void boundaryzet(double *zet, double *psi, int m, int n);
