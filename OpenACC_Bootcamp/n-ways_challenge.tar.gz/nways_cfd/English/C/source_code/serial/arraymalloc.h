#include <stddef.h>

void **arraymalloc2d(int nx, int ny, size_t typesize);

